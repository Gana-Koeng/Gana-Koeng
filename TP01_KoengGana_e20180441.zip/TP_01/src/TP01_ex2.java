//exercise02
public class TP01_ex2 {
	public static void main (String [] args) {
        System.out.print ("\\n				Line Break.\r\n"+
        				  "\\b				Erase on Character.\r\n"+
        				  "\\t				Tabilation.\r\n"+
        				  "\\'				Single Quote.\r\n"+
        				  "\\				Double Quote.\r\n"+
        				  "\\\\				\\Sign.\r\n"+
        				  "\\\\\\\\				\\\\Sign.\r\n"+
        				  "//				Line Comment.\r\n"+
        				  "/* ... */			Block Comment.\r\n");
        				   
}}
