//excercise01
public class TP01_ex1 {
    public static void main(String[] args) {
        System.out.println("Hello, Koeng Gana"); 
    }
}
