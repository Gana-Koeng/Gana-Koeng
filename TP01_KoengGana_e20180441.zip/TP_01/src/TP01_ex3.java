//exercise03

	public class TP01_ex3  {
		public static void main (String [] args) {
	        System.out.println ("A."); 
	        System.out.print ("*************************   \n");
	        System.out.print ("*                       *   \n");
	        System.out.print ("*                       *   \n");
	        System.out.print ("*                       *   \n");
	        System.out.print ("*                       *   \n");
	        System.out.print ("*************************   \n");
	        
	        System.out.println ("\nB."); 
	        System.out.print ("    *   \n");
	        System.out.print ("   ***   \n");
	        System.out.print ("  *****   \n");
	        System.out.print (" *******   \n");
	        System.out.print ("*********   \n");
	        
	        System.out.println ("\nC.");
	        System.out.print ("* \n");
	        System.out.print ("** \n");
	        System.out.print ("*** \n");
	        System.out.print ("**** \n");
	        System.out.print ("*****   \n");
	        System.out.print ("******   \n");
	        
	        System.out.println ("\nD.");
	        System.out.print ("****** \n");
	        System.out.print (" ***** \n");
	        System.out.print ("  **** \n");
	        System.out.print ("   *** \n");
	        System.out.print ("    ** \n");
	        System.out.print ("     * \n");
	        
	        System.out.println ("\nE.");
	        System.out.print ("    * \n");
	        System.out.print ("  *** \n");
	        System.out.print ("***** \n");
	        System.out.print ("  *** \n");
	        System.out.print ("    * \n");
	        
	        System.out.println ("\nF.");
	        System.out.print ("  *  \n");
	        System.out.print (" *** \n");
	        System.out.print ("*****\n");
	        System.out.print (" *** \n");
	        System.out.print ("  *  \n");
	        
	        System.out.println ("\nG.");
	        System.out.print ("*****    \n");
	        System.out.print (" ***     \n");
	        System.out.print ("  *      \n");
	        System.out.print (" ***     \n");
	        System.out.print ("******   \n");
	        
	        System.out.println ("\nH.");
	        System.out.print ("   * \n");
	        System.out.print (" *   * \n");
	        System.out.print ("*     * \n");
	        System.out.print (" *   *  \n");
	        System.out.print ("   *   \n");




	 
	    }
	}

