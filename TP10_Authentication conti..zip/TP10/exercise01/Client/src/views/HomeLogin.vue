<script setup>
import LoginForm from "@/components/LoginForm.vue";
// import TheWelcome from '@/components/TheWelcome.vue'
</script>

<template>
  <main>
    <LoginForm />
  </main>
</template>
