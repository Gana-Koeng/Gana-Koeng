<script setup>
import SignupForm from "@/components/SignupForm.vue";
// import TheWelcome from '@/components/TheWelcome.vue'
</script>

<template>
  <main>
    <SignupForm />
  </main>
</template>
