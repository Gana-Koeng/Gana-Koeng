import java.util.Scanner;
public class TP02_ex5 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.print("Program for guessing your luckiness.\n");
		System.out.print("Please input a number: ");	
		int number = sc.nextInt();
		int num = number + 1;
		System.out.println("I got "+num+". I am luckier.");	

	}
}
