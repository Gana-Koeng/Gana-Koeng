import java.util.Scanner;  
	

public class TP02_ex2 {

public static void main (String[] args) {
	Scanner sc = new Scanner(System. in);
	int width, height;
	System. out.print("Input your width(in meter):");
	width = sc.nextInt();
	System. out.print("Input your hight(in meter):");
	height = sc.nextInt();
	System. out.println("perimter" + "("+width +"+"+ height+")"+"*2"+"="+((width+height)*2)+"m");
	System. out.println("perimter ="+width +"*"+ height+"="+(width*height)+ "m^2");
	
}
}
