import java.util.Scanner;
public class TP02_ex3 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);	
		    System.out.print("Program for calculate 1/x = 1/y + 1/z\n");      
			System.out.print("Please input y: ");
			
			float y = sc.nextFloat();
			System.out.print("Please input z: ");
			
			float z = sc.nextFloat();
			float yz = y * z;
	     	float yplusz = y + z ;
			float x = yz / yplusz;	
			
			System.out.println("Result x: "+x);
			
					
}
}
