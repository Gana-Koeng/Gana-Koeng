import java.util.Scanner;
public class TP03_ex4 {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		
		System.out.printf("Program for counting the number of hundreds.\n");
		System.out.printf("Please input a positive number: ");	
		int number = sc.nextInt();
		int hundred = number/100;
		
		System.out.printf("There are "+hundred+ " hundreds in number "+number+".");
		
	}

}
