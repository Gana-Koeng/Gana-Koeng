import java.util.Scanner;
public class TP03_ex2
{
    public static void main(String args[]) {
        
        Scanner in = new Scanner(System.in);
        
        System.out.print("Program for converting time to seconds.\n");
        System.out.print("Please input hours: ");
        int hrs = in.nextInt();
        System.out.print("Please input minutes: ");
        int mins = in.nextInt();
        System.out.print("Please input seconds: ");
        int secs = in.nextInt();
        
        
        System.out.println("Number of seconds="+  ((hrs = hrs * 3600) + (mins = mins*60)  + secs));
    }
}