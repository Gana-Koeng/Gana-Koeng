import java.util.Scanner;
public class TP03_ex5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.printf("Program for calculating duration of travel from ITC to Airport.");
		System.out.printf("\nPlease input traffic jam factor (in percentage [0-100]):");
		int percentage = sc.nextInt();
		double distance = 7.0 ;
		double speed = 30.0 ; 
		if(percentage >= 99) {
			System.out.printf("\nYou cannot arrive.");}
		double Time = distance / speed ; 
		double travel = (Time*100)/(100-percentage);
		double seconds = travel*3600;		
		double hh = seconds / 3600;
		double mm = (seconds % 3600)/ 60;
		double ss =  seconds % 60;
		System.out.printf("\nTravelling Duration =  %02.0f:%02.0f:%02.0f ",hh,mm,ss);
		
	}

}
