import java.util.*;
 public class TP03_ex1{
 public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Input number of seconds: ");
		int seconds = in.nextInt(); 
        int p1 = seconds % 60;
        int p2 = seconds / 60;
        int p3 = p2 % 60;
        p2 = p2 / 60;
        System.out.print("Time corresponding to "+ seconds +" is "+ p2 + ":" + p3 + ":" + p1);
	
    }    
 }
